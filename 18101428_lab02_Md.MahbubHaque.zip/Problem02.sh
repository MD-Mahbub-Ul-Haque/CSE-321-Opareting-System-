#!/bin/bash

touch file.txt

echo "Enter your name: "

read name

echo -e $name >> file.txt